<?php 


 $file = 'people.txt'; 

$person =  $_REQUEST;   print_r($_REQUEST);
 
file_put_contents(__DIR__.$file, print_r($person,true), FILE_APPEND | LOCK_EX);